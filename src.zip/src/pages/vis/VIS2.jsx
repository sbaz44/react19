import React from "react";
import { observer, useObservable } from "@legendapp/state/react";
import { useEffect } from "react";
import { useRef } from "react";
import { Timeline } from "vis-timeline/standalone";
import { DataSet } from "vis-data";
export default function VIS2() {
  const timelineRef = useRef(null);
  const timeline = useRef(null);
  const playbackIntervalRef = useRef(null);

  const { RecordingsData, CurrentTime } = useObservable({
    RecordingsData: recordingsData,
    CurrentTime: null,
  });

  useEffect(() => {
    const findTimeRange = (data) => {
      let earliestTime = null;
      let latestTime = null;

      Object.values(data).forEach((recordings) => {
        const sortedRecordings = [...recordings].sort(
          (a, b) => new Date(a.StartTime) - new Date(b.StartTime)
        );

        if (sortedRecordings.length > 0) {
          const firstStart = new Date(sortedRecordings[0].StartTime);
          if (!earliestTime || firstStart < earliestTime) {
            earliestTime = firstStart;
          }

          const totalDuration = sortedRecordings.reduce(
            (sum, rec) => sum + rec.Duration,
            0
          );
          const lastTime = new Date(
            firstStart.getTime() + totalDuration * 1000
          );
          if (!latestTime || lastTime > latestTime) {
            latestTime = lastTime;
          }
        }
      });

      return { earliestTime, latestTime };
    };

    const transformDataForTimeline = (data) => {
      const groups = [];
      const items = [];
      let itemId = 1;

      Object.keys(data).forEach((cameraName, groupIndex) => {
        groups.push({
          id: groupIndex + 1,
          content: cameraName.charAt(0).toUpperCase() + cameraName.slice(1),
          className: `camera-group-${groupIndex + 1}`,
        });

        const sortedRecordings = [...data[cameraName]].sort(
          (a, b) => new Date(a.StartTime) - new Date(b.StartTime)
        );

        const firstStartTime = new Date(sortedRecordings[0].StartTime);
        let continuousStartTime = firstStartTime;

        sortedRecordings.forEach((recording, recordingIndex) => {
          const originalStartTime = new Date(recording.StartTime);
          const durationMs = recording.Duration * 1000;
          const continuousEndTime = new Date(
            continuousStartTime.getTime() + durationMs
          );
          const fileName = recording.Path.split("/").pop().replace(".mp4", "");
          const originalEndTime = new Date(
            originalStartTime.getTime() + durationMs
          );

          items.push({
            id: itemId++,
            group: groupIndex + 1,
            //   content: `${fileName.substring(11, 19)}`,
            start: continuousStartTime,
            end: continuousEndTime,
            type: "range",
            className: `recording-item camera-${groupIndex + 1}`,
            originalData: {
              ...recording,
              originalStartTime: originalStartTime,
              originalEndTime: originalEndTime,
              continuousStartTime: continuousStartTime,
              continuousEndTime: continuousEndTime,
            },
          });

          continuousStartTime = continuousEndTime;
        });
      });

      return { groups, items };
    };

    const { groups, items } = transformDataForTimeline(RecordingsData.get());
    const groupsDataSet = new DataSet(groups);
    const itemsDataSet = new DataSet(items);

    const { earliestTime, latestTime } = findTimeRange(RecordingsData.get());
    if (!CurrentTime.get() && earliestTime) {
      CurrentTime.set(earliestTime);
    }

    const options = {
      stack: false,
      height: "400px",
      editable: false,
      selectable: false,
      orientation: "top",
      showCurrentTime: false,
      //  zoomMin: 1000 * 60,
      zoomMax: 1000 * 60 * 60 * 24,
      groupOrder: "content",
      format: {
        minorLabels: {
          minute: "HH:mm",
          hour: "HH:mm",
        },
        majorLabels: {
          minute: "ddd DD MMM",
          hour: "ddd DD MMM",
        },
      },
    };

    if (timelineRef.current) {
      timeline.current = new Timeline(
        timelineRef.current,
        itemsDataSet,
        groupsDataSet,
        options
      );

      setTimeout(() => {
        if (timeline.current && CurrentTime.get()) {
          try {
            timeline.current.addCustomTime(CurrentTime.get(), "playback");
            timeline.current.setCustomTimeTitle(
              "Playback Position",
              "playback"
            );
          } catch (error) {
            console.log("Custom time already exists or timeline not ready");
          }
        }
      }, 100);

      timeline.current.on("timechange", (event) => {
        if (event.id === "playback") {
          CurrentTime.set(event.time);
        }
      });
    }

    return () => {
      if (playbackIntervalRef.current) {
        clearInterval(playbackIntervalRef.current);
      }
      if (timeline.current) {
        timeline.current.destroy();
      }
    };
  }, []);

  return (
    <div>
      {/* Timeline */}
      <div
        ref={timelineRef}
        style={{ border: "1px solid #ddd", borderRadius: "4px" }}
      />
    </div>
  );
}

const recordingsData = {
  "camera 1": [
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-46-45-895.mp4",
      Duration: 60.08000183105469,
      StartTime: "2025-07-28T15:46:45+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-47-45-896.mp4",
      Duration: 60.400001525878906,
      StartTime: "2025-07-28T15:47:45+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-48-46-897.mp4",
      Duration: 63.2400016784668,
      StartTime: "2025-07-28T15:48:46+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-49-49-898.mp4",
      Duration: 60.20000076293945,
      StartTime: "2025-07-28T15:49:49+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-50-49-899.mp4",
      Duration: 63.84000015258789,
      StartTime: "2025-07-28T15:50:49+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-51-53-900.mp4",
      Duration: 63.91999816894531,
      StartTime: "2025-07-28T15:51:53+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-52-57-901.mp4",
      Duration: 60.119998931884766,
      StartTime: "2025-07-28T15:52:57+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376f5e6f5c6a7b8d07579/2025-07-28/2025-07-28-15-53-57-902.mp4",
      Duration: 63.880001068115234,
      StartTime: "2025-07-28T15:53:57+05:30",
    },
  ],
  "camera 2": [
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-47-11-1691.mp4",
      Duration: 63.14899826049805,
      StartTime: "2025-07-28T15:47:11+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-48-13-1692.mp4",
      Duration: 61.25400161743164,
      StartTime: "2025-07-28T15:48:13+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-49-13-1693.mp4",
      Duration: 63.159000396728516,
      StartTime: "2025-07-28T15:49:13+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-50-15-1694.mp4",
      Duration: 63.19200134277344,
      StartTime: "2025-07-28T15:50:15+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-51-17-1695.mp4",
      Duration: 63.21799850463867,
      StartTime: "2025-07-28T15:51:17+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-52-19-1696.mp4",
      Duration: 63.154998779296875,
      StartTime: "2025-07-28T15:52:19+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-53-21-1697.mp4",
      Duration: 63.22800064086914,
      StartTime: "2025-07-28T15:53:21+05:30",
    },
    {
      Path: "/static_server/recorder/recordings/688376fae6f5c6a7b8d0757a/2025-07-28/2025-07-28-15-54-23-1698.mp4",
      Duration: 63.16600036621094,
      StartTime: "2025-07-28T15:54:23+05:30",
    },
  ],
};
